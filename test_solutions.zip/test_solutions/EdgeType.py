from enum import Enum


class EdgeType(Enum):
    LEFT_TO_LEFT = 0
    LEFT_TO_RIGHT = 1
    RIGHT_TO_LEFT = 2
    RIGHT_TO_RIGHT = 3

