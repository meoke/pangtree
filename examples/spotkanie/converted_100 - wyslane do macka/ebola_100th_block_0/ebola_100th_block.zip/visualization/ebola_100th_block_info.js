var info = 
                { name: 'ebola_100th_block', 
consensus_algorithm: 3, 
running_time:'00:00:02', 
sources_count: 158, 
nodes_count: 501, 
sequences_per_node: 65.43, 
levels: [0.6, 0.7]};